const cards = document.getElementById("cards");
function markdown(input) {
    return input.replace(/^### (.*$)/g, "<h3>$1</h3>").replace(/^## (.*$)/g, "<h2>$1</h2>").replace(/^# (.*$)/g, "<h1>$1</h1>").replace(/\[(.*?)\]\((.*?)\)/g, "<a href=\"$2\">$1</a>").replace(/___(.*)___/g, "<em><u>$1</u></em>").replace(/__(.*)__/g, "<u>$1</u>").replace(/_(.*)_/g, "<u>$1</u>").replace(/\*\*\*(.*)\*\*\*/g, "<em><strong>$1</strong></em>").replace(/\*\*(.*)\*\*/g, "<strong>$1</strong>").replace(/\*(.*)\*/g, "<em>$1</em>").trim();
}

function init() {
    for (const item of items) {
        const card = document.createElement("div");
        card.className = "card";

        if (item.credits) {
            const credits = document.createElement("ul");
            credits.className = "credits";
            for (const credit of item.credits) {
                const cont = document.createElement("li");
                const link = document.createElement("a");
                link.href = credit.url || "#";
                link.target = "_blank";
                link.innerHTML = "-";
                link.title = credit.name || "Anonymous";

                cont.appendChild(link);
                credits.appendChild(cont);
            }

            card.appendChild(credits);
        }

        const title = document.createElement("div");
        const titleText = document.createElement("a");
        title.className = "title";
        titleText.className = "text";
        titleText.href = item.title.url;
        titleText.target = "_blank";
        titleText.innerHTML = item.title.text;
        title.appendChild(titleText);

        const images = document.createElement("div");
        const image = new Image;
        images.className = "image";

        image.src = item.image.url;
        images.appendChild(image);

        const description = document.createElement("div");
        description.className = "description";
        description.innerHTML = markdown(item.description) || "No information available!";

        card.append(images, title, description);
        cards.appendChild(card);
    }
}

init();